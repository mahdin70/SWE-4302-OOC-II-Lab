package Task3;

public class Calculator implements GenericOperation{
    @Override
    public double add(double Num1, double Num2){
        return Num1+Num2;
    }

    @Override
    public double subtract(double Num1,double Num2){
        return Num1 - Num2;

    }
    @Override
    public double multiply(double Num1, double Num2){
        return Num1 * Num2;
    }

    @Override
    public double division(double Num1,double Num2){
        return Num1/Num2;
    }
}
