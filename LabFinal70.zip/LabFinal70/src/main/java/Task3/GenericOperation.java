package Task3;

public interface GenericOperation<T> {

    public default T add(T Num1, T Num2){
        return Num1 + Num2;
    }
    public default T subtract(T Num1, T Num2){
        return Num1 - Num2;
    }
    public default T multiply(T Num1, T Num2){
        return Num1*Num2;
    }
    public default T divide(T Num1, T Num2){
        return Num1/Num2;
    }
}
