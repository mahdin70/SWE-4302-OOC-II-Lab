package Task2;

public class Book {
    String Title;
    String Author;

    public Book(String Title, String Author) {
        this.Title = Title;
        this.Author = Author;
    }
}
