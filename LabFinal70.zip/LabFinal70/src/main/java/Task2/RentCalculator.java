package Task2;

public interface RentCalculator {
    public double calculateRent(RentBook rentBook);
}
