package Task1.B;

public class TestMail{
    SendEmail sendEmail = new SendEmail("abc@gmail.com","bcd@yahoo.com","None",new Mail("Hello","Hello World"));
}
