package Task1.B;

public class Mail {
    String Subject;
    String Body;

    public Mail(String Subject, String Body){
        this.Subject = Subject;
        this.Body = Body;
    }
}
