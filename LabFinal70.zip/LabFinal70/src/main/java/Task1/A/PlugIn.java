package Task1.A;

// A separate interface is created named "PlugIn" to impose DIP and ISP on the Computer Class
public interface PlugIn {
    public void plugIn(Computer c);
}
