package Task1.A;

public interface Hibernate {
    public void hibernate(Computer c);
}

