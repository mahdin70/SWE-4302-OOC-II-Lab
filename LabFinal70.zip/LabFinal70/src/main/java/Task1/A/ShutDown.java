package Task1.A;

//Shutdown interface is created to impose DIP and ISP on the Computer Class
public interface ShutDown {
    public void shutDown(Computer c);
}

